const express = require('express');
const router = express.Router();
const fs = require('fs');
const path = require('path');
 
const FabricCAServices = require('fabric-ca-client');
const { FileSystemWallet, X509WalletMixin, Gateway } = require('fabric-network');
 
const ccpPath = path.resolve(__dirname, '..' , 'first_articles', 'connection-org1.json');
const ccpJSON = fs.readFileSync(ccpPath, 'utf8');
const ccp = JSON.parse(ccpJSON);
 
// Create a new CA client for interacting with the CA.
const caInfo = ccp.certificateAuthorities['ca.org1.example.com'];
const caTLSCACerts = caInfo.tlsCACerts.pem;
const ca = new FabricCAServices(caInfo.url, { trustedRoots: caTLSCACerts, verify: false }, caInfo.caName);
 
// Create a new file system based wallet for managing identities.
const walletPath = path.join(process.cwd(), 'wallet1');
const wallet = new FileSystemWallet(walletPath);
console.log(`Wallet path: ${walletPath}`);


/* GET */
router.get('/add', async function(req, res, next) {
    console.log(req.query.number);
    console.log(req.query.model);
    console.log(req.query.date);
    console.log(req.query.level);
    console.log(req.query.safty);
    console.log(req.query.owner);
    console.log(req.query.reuse);
    console.log(req.query.carnumber);
    console.log(req.query.supporter);

    
    let number = req.query.number;
    let model = req.query.model;//args[1];
    let date = req.query.date;//args[2];    
    let level = req.query.level;
    let safty = req.query.safty;    
    let owner = req.query.owner;
    let reuse = req.query.reuse;
    let carnumber = req.query.carnumber;
    let supporter = req.query.supporter;   
    
    try{
        // Create a new file system based wallet for managing identities.
        
        console.log(`Wallet path: ${walletPath}`);
    
        // Check to see if we've already enrolled the user.
        const userExists = await wallet.exists('user1');
        if (!userExists) {
            console.log('An identity for the user "user1" does not exist in the wallet');
            console.log('Run the registerUser.js application before retrying');
            return;
        }
    
        // Create a new gateway for connecting to our peer node.
        const gateway = new Gateway();
        //console.log("@@@@@@@",gateway);
        //console.log("@@@@@@@",ccpPath);
        await gateway.connect(ccpPath, { wallet, identity: 'user1', discovery: { enabled: true, asLocalhost: false } });
       // console.log("@@@@@@@",1);
        // Get the network (channel) our contract is deployed to.
        const network = await gateway.getNetwork('mychannel');
        
        //let peers = network.getChannel().getChannelPeers();
        //console.log("@@@@@@@",peers);
        // Get the contract from the network.
        const contract = network.getContract('battery');
        //console.log("@@@@@@@",contract);
        // Evaluate the specified transaction.   
        await contract.submitTransaction('createBattery',number,model,date,level,safty,owner,reuse,carnumber,supporter);        
        res.send(`블록체인에 배터리 정보가 저장되었습니다 `);
    }catch(e){
        console.log(e);
        res.send('<h1>블록체인 저장 실패</h1>');
    }
  });


/* GET */
router.get('/query', async (req, res, next) => {
    try{
    // Create a new file system based wallet for managing identities.
    
    console.log(`Wallet path: ${walletPath}`);

    // Check to see if we've already enrolled the user.
    const userExists = await wallet.exists('user1');
    if (!userExists) {
        console.log('An identity for the user "user1" does not exist in the wallet');
        console.log('Run the registerUser.js application before retrying');
        return;
    }

    // Create a new gateway for connecting to our peer node.
    const gateway = new Gateway();
    await gateway.connect(ccpPath, { wallet, identity: 'user1', discovery: { enabled: true, asLocalhost: false } });

    // Get the network (channel) our contract is deployed to.
    const network = await gateway.getNetwork('mychannel');

    // Get the contract from the network.
    const contract = network.getContract('battery');

    // Evaluate the specified transaction.   
    const a_result = await contract.evaluateTransaction('queryAllBattery');

    
    
        console.log(`Transaction has been evaluated, result is: ${a_result.toString()} `);
        res.send(a_result.toString());
    }catch(e){
        console.log(e);
        res.send(e);
    }
    }
);
 


  
module.exports = router;
