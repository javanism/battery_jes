const express=require("express");
const path=require("path");
var session=require('express-session');
var cookieParser = require('cookie-parser');

const app=express();

app.use(express.urlencoded({ extended: false }));
app.use(cookieParser('!@#$%^&*()전은수는예쁘다'));
app.use(session({
  name:'JES_SID',
  timeout:30,
  resave:false,
  saveUninitialized:false,
  secret:'!@#$%^&*()전은수는예쁘다',
  cookie:{
    httpOnly:true,
    secure:false   
  }
  }));




app.use(express.static(path.join(__dirname,"/public")));
app.use(express.json());

app.use('/battery',require('./routes/battery'));

app.listen(3000,function(){
    console.log("3000 server ready...");
});
















