/*
# Copyright IBM Corp. All Rights Reserved.
#
# SPDX-License-Identifier: Apache-2.0
*/

'use strict';
const shim = require('fabric-shim');
const util = require('util');

let Chaincode = class {

  // ===============================================
  // Init
  // ===============================================
  async Init(stub) {
    console.info('=========== Instantiated fabcar chaincode ===========');
    return shim.success();
  }



  // ===============================================
  // Invoke
  // ===============================================
  async Invoke(stub) {
    let ret = stub.getFunctionAndParameters();
    	console.info(ret);
	console.log('==========^^================',ret);
    	console.info(ret.fcn);
	console.log('==========^^================',ret.fcn);

    let method = this[ret.fcn];
    if (!method) {
      console.error('no function of name:' + ret.fcn + ' found');
      throw new Error('Received unknown function ' + ret.fcn + ' invocation');
    }
    try {
      let payload = await method(stub, ret.params, this);
      return shim.success(payload);
    } catch (err) {
      console.log(err);
      return shim.error(err);
    }
  }



  // ===============================================
  // initLedger
  // ===============================================
  async initLedger(stub, args) {
    console.info('============= START : Initialize Ledger ===========');
    let batteries = [];
    batteries.push({ 	  
	  model : "HD0034",
	  date : "1994-12-21",
	  level : "B--",
	  safty : "S1",
	  owner : "Joy",
	  reuse : "Factory-ESS",
	  carnumber : "C65-4073", 
	  supporter : "Seoul"
    });
 
    batteries.push({ 	  
	  model : "TY0055",
	  date : "2013-03-17",
	  level : "C++",
	  safty : "S4",
	  owner : "James",
	  reuse : "Home-ESS",
	  carnumber : "H53-0047", 
	  supporter : "Busan"
    });

    batteries.push({ 	  
	  model : "KA0065",
	  date : "2018-08-20",
	  level : "D--",
	  safty : "S3",
	  owner : "Tom",
	  reuse : "Factory-REC",
	  carnumber : "T43-4330", 
	  supporter : "Hanam"
    });
    

    for (let i = 0; i < batteries.length; i++) {
      batteries[i].docType = 'battery';
      await stub.putState('B' + i, Buffer.from(JSON.stringify(batteries[i])));
      console.info('Added <--> ', batteries[i]);
    }
    console.info('============= END : Initialize Ledger ===========');

  }


  // ===============================================
  // getBattery - Query a battery from blockchain
  // ===============================================
  async getBattery(stub, args, thisClass) {
    if (args.length != 1) {
      throw new Error('Incorrect number of arguments. Expecting number of the battery to query');
    }

    let batteryNumber = args[0];
    if (!batteryNumber) {
      throw new Error('battery number must not be empty');
    }
    let batteryAsbytes = await stub.getState(batteryNumber); //get the battery number from chaincode state
    if (!batteryAsbytes.toString()) {
      let jsonResp = {};
      jsonResp.Error = 'Battery does not exist: ' + batteryNumber;
      throw new Error(JSON.stringify(jsonResp));
    }
    console.info('=======================================');
    console.log(batteryAsbytes.toString());
    console.info('=======================================');
    return batteryAsbytes;
    }



  // ===============================================
  // queryAllBattery - Query All battery from blockchain
  // ===============================================
  async queryAllBattery(stub, args) {
console.log('>>>>>>>>>>>>>>>>>>>queryAllBattery 4.4');
    let startKey = 'B0';
    let endKey = 'B99';

    let iterator = await stub.getStateByRange(startKey, endKey);

    let allResults = [];
    while (true) {
      let res = await iterator.next();

      if (res.value && res.value.value.toString()) {
        let jsonRes = {};
        console.log(res.value.value.toString('utf8'));

        jsonRes.Key = res.value.key;
        try {
          jsonRes.Record = JSON.parse(res.value.value.toString('utf8'));
        } catch (err) {
          console.log(err);
          jsonRes.Record = res.value.value.toString('utf8');
        }
        allResults.push(jsonRes);
      }
      if (res.done) {
        console.log('end of data');
        await iterator.close();
        console.info(allResults);
        return Buffer.from(JSON.stringify(allResults));
      }
    }
  }



  // ===============================================
  // createBattery - create a new battery registration 
  // ===============================================

async createBattery(stub, args, thisClass) {
    if (args.length != 9) {
      throw new Error('Incorrect number of arguments. Expecting 9');
    }

    // ==== Input sanitation ====
    console.info('--- start init battery ---')
    if (args[0].lenth <= 0) {
      throw new Error('1st argument must be a non-empty string');
    }
    if (args[1].lenth <= 0) {
      throw new Error('2nd argument must be a non-empty string');
    }
    if (args[2].lenth <= 0) {
      throw new Error('3rd argument must be a non-empty string');
    }
    if (args[3].lenth <= 0) {
      throw new Error('4th argument must be a non-empty string');
    }
    if (args[4].lenth <= 0) {
      throw new Error('5th argument must be a non-empty string');
    }
    if (args[5].lenth <= 0) {
      throw new Error('6th argument must be a non-empty string');
    }
    if (args[6].lenth <= 0) {
      throw new Error('7th argument must be a non-empty string');
    }
    if (args[7].lenth <= 0) {
      throw new Error('8th argument must be a non-empty string');
    }
    if (args[8].lenth <= 0) {
      throw new Error('9th argument must be a non-empty string');
    }

    let number = args[0];
    let model = args[1];
    let date = args[2];
    let level = args[3];
    let safty = args[4];    
    let owner = args[5];
    let reuse = args[6];
    let carnumber = args[7];
    let supporter = args[8];

    // ==== Check if battery already exists ====
    
    let batteryState = await stub.getState(number);
    if (batteryState.toString()) {      
      throw new Error('This batter already exists: ' + number);
    }


    // ==== Create battery object and marshal to JSON ====
    let battery = {};
    battery.docType = 'battery';
    battery.number = number;
    battery.model = model;
    battery.date = date;
    battery.level = level;
    battery.safty = safty;
    battery.owner = owner;
    battery.reuse = reuse;
    battery.carnumber = carnumber; 
    battery.supporter = supporter; 

    // === Save battery to state ===
    await stub.putState(number, Buffer.from(JSON.stringify(battery)));
    console.info('- end create battery');
    
  }

  // ===========================================================
  // transferBattery - change the new battery owner 
  // ===========================================================

  async transferBattery(stub, args, thisClass) {

    if (args.length < 2) {
      throw new Error('Incorrect number of arguments. Expecting battery number and owner')
    }

    let batteryNumber = args[0];
    let newOwner = args[1].toLowerCase();
    console.info('- start transferMarble ', batteryNumber, newOwner);

    let batteryAsBytes = await stub.getState(batteryNumber);
    if (!batteryAsBytes || !batteryAsBytes.toString()) {
      throw new Error('battery does not exist');
    }

    let batteryToTransfer = {};
    try {
      batteryToTransfer = JSON.parse(batteryAsBytes.toString()); //unmarshal
    } catch (err) {
      let jsonResp = {};
      jsonResp.error = 'Failed to decode JSON of: ' + batteryNumber;
      throw new Error(jsonResp);
    }
    console.info(batteryToTransfer);
    batteryToTransfer.owner = newOwner; //change the owner

    let batteryJSONasBytes = Buffer.from(JSON.stringify(batteryToTransfer));
    await stub.putState(batteryNumber, batteryJSONasBytes); //rewrite the battery

    console.info('- end transferBattery (success)');

    }

  // ===========================================================
  // getHistroyForBattery - tracing the battery history   
  // ===========================================================

   async getHistoryForBattery(stub, args, thisClass) {

    if (args.length < 1) {
      throw new Error('Incorrect number of arguments. Expecting 1')
    }
    let batteryNumber = args[0];
    console.info('- start getHistoryForBattery: %s\n', batteryNumber);

    let resultsIterator = await stub.getHistoryForKey(batteryNumber);
    let method = thisClass['getAllResults'];
    let results = await method(resultsIterator, true);

    return Buffer.from(JSON.stringify(results));
   }



  async getAllResults(iterator, isHistory) {
    let allResults = [];
    while (true) {
      let res = await iterator.next();

      if (res.value && res.value.value.toString()) {
        let jsonRes = {};
        console.log(res.value.value.toString('utf8'));

        if (isHistory && isHistory === true) {
          jsonRes.TxId = res.value.tx_id;
          jsonRes.Timestamp = res.value.timestamp;
          jsonRes.IsDelete = res.value.is_delete.toString();
          try {
            jsonRes.Value = JSON.parse(res.value.value.toString('utf8'));
          } catch (err) {
            console.log(err);
            jsonRes.Value = res.value.value.toString('utf8');
          }
        } else {
          jsonRes.Key = res.value.key;
          try {
            jsonRes.Record = JSON.parse(res.value.value.toString('utf8'));
          } catch (err) {
            console.log(err);
            jsonRes.Record = res.value.value.toString('utf8');
          }
        }
        allResults.push(jsonRes);
      }
      if (res.done) {
        console.log('end of data');
        await iterator.close();
        console.info(allResults);
        return allResults;
      }
    }
  }



};

shim.start(new Chaincode());
