rm -rf ./wallet1
rm -rf ./wallet2
rm -rf ./wallet3
rm -rf ./wallet4
node enrollAdmin
node registerUser

