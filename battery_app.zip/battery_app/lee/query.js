/*
 * SPDX-License-Identifier: Apache-2.0
 */

'use strict';

const { FileSystemWallet, Gateway } = require('fabric-network');
const path = require('path');



async function main() {
    try {

	let myArgs = process.argv.slice(2);
	let i=myArgs[0];
	
	const ccpPath = path.resolve(__dirname, '..', '..', 'first-network-4org', `connection-org${i}.json`);
	// Create a new file system based wallet for managing identities.
	const walletPath = path.join(process.cwd(), `wallet${i}`);
	const wallet = new FileSystemWallet(walletPath);
	console.log(`Wallet path: ${walletPath}`);

	// Check to see if we've already enrolled the user.
	const userExists = await wallet.exists('user1');
	if (!userExists) {
	    console.log(`An identity for the user "user1" does not exist in the wallet${i}`);
	    console.log('Run the registerUser.js application before retrying');
	    return;
	}

	// Create a new gateway for connecting to our peer node.
	const gateway = new Gateway();
	await gateway.connect(ccpPath, { wallet, identity: 'user1', discovery: { enabled: true, asLocalhost: true } });

	// Get the network (channel) our contract is deployed to.
	const network = await gateway.getNetwork('mychannel');

	// Get the contract from the network.
	const contract = network.getContract('battery');

	// Evaluate the specified transaction.
	// queryCar transaction - requires 1 argument, ex: ('queryCar', 'CAR4')
	// queryAllCars transaction - requires no arguments, ex: ('queryAllCars')
	//const result = await contract.evaluateTransaction('getHistoryForCar','CAR0','');
	//const result = await contract.evaluateTransaction('queryCar', 'B0');
	//const result = await contract.evaluateTransaction('queryAllBattery');
	//console.log(`Transaction has been evaluated, result is: ${result.toString()}`);


    let model = "KA0065";//args[1];
    let date = Date.now()+'';//args[2];    
    let level = "D--";
    let safty = "S3";    
    let owner = "Jes";
    let reuse = "Factory-REC";
    let carnumber = "T43-4330";
    let supporter = "Hanam";  
	
await contract.submitTransaction('createBattery','B5',model,date,level,safty,owner,reuse,carnumber,supporter);        
        console.log(`블록체인에 배터리 정보가 저장되었습니다 `);

    } catch (error) {
        console.error(`Failed to evaluate transaction: ${error}`);
        process.exit(1);
    }
}

main();
