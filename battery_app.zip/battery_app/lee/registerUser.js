/*
 * SPDX-License-Identifier: Apache-2.0
 */

'use strict';

const { FileSystemWallet, Gateway, X509WalletMixin } = require('fabric-network');
const path = require('path');



async function main() {
    try {
	for(let i=1;i<5;i++){

		const ccpPath = path.resolve(__dirname, '..', '..', 'first-network-4org', `connection-org${i}.json`);

		// Create a new file system based wallet for managing identities.
		const walletPath = path.join(process.cwd(), `wallet${i}`);
		const wallet = new FileSystemWallet(walletPath);
		console.log(`Wallet path: ${walletPath}`);

		// Check to see if we've already enrolled the user.
		const userExists = await wallet.exists('user1');
		if (userExists) {
		    console.log(`An identity for the user "user1" already exists in the wallet${i}`);
		    return;
		}

		// Check to see if we've already enrolled the admin user.
		const adminExists = await wallet.exists('admin');
		if (!adminExists) {
		    console.log(`An identity for the admin user "admin" does not exist in the wallet${i}`);
		    console.log('Run the enrollAdmin.js application before retrying');
		    return;
		}

		// Create a new gateway for connecting to our peer node.
		const gateway = new Gateway();
		await gateway.connect(ccpPath, { wallet, identity: 'admin', discovery: { enabled: true, asLocalhost: true } });
//console.log("1",gateway);
//console.log("2",gateway.getClient());

		// Get the CA client object from the gateway for interacting with the CA.
		const ca = gateway.getClient().getCertificateAuthority();
//console.log("3",ca);
		const adminIdentity = gateway.getCurrentIdentity();
//console.log("4",adminIdentity);
		// Register the user, enroll the user, and import the new identity into the wallet.
		//const secret = await ca.register({ affiliation: `org${i}.department1`, enrollmentID: 'user1', role: 'client' }, adminIdentity);

const secret = await ca.register({  enrollmentID: 'user1', role: 'client' }, adminIdentity);
		const enrollment = await ca.enroll({ enrollmentID: 'user1', enrollmentSecret: secret });
		const userIdentity = X509WalletMixin.createIdentity(`Org${i}MSP`, enrollment.certificate, enrollment.key.toBytes());
		await wallet.import('user1', userIdentity);
		console.log(`Successfully registered and enrolled admin user "user1" and imported it into the wallet${i}`);
	}

    } catch (error) {
        console.error(`Failed to register user "user1": ${error}`);
        process.exit(1);
    }
}

main();
